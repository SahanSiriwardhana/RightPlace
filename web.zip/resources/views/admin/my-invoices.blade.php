<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from expert-themes.com/html/willies/admin/my-invoices.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 11 Dec 2018 11:41:22 GMT -->
<head>
<meta charset="utf-8">
<title>Willies - Real Estate HTML Template | My Invoices</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">

    <!-- Preloader -->
    <div class="preloader"></div>

    <!-- Header Span -->
    <span class="header-span"></span>

    <!-- Main Header-->
    <header class="main-header">
        <div class="main-box clearfix">
        	<!-- Logo Box -->
            <div class="logo-box">
                <div class="logo"><a href="../index-2.html"><img src="images/logo-small.png" alt="" title=""></a></div>
            </div>

            <!-- Upper Right-->
            <div class="upper-right">
                <ul class="clearfix">
                    <li class="dropdown option-box">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="images/resource/thumb-1.jpg" alt="avatar" class="thumb">My Account</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="dashboard.html">Dashboard</a>
                            <a class="dropdown-item" href="messages.html">Messages</a>
                            <a class="dropdown-item" href="bookings.html">Bookings</a>
                            <a class="dropdown-item" href="my-profile.html">My profile</a>
                            <a class="dropdown-item" href="../index-2.html">Log out</a>
                        </div>
                    </li>
                    <li class="submit-property">
                        <a href="submit-property.html" class="theme-btn btn-style-one">Submit Property <i class="pe-7s-up-arrow"></i></a>
                    </li>
                    <li class="nav-toggler">
                    	<button class="toggler-btn nav-btn"><span class="bar bar-one"></span><span class="bar bar-two"></span><span class="bar bar-three"></span></button>
                    </li>
                </ul>
            </div>
        </div>
        <!--End Header Lower-->
    </header>
    <!--End Main Header -->
    
    <!-- Hidden Bar -->
    <section class="hidden-bar">
        <div class="dashboard-inner">
        	<div class="cross-icon"><span class="pe-7s-close-circle"></span></div>
        	<ul class="navigation">
	            <li><a href="dashboard.html"><i class="pe-7s-culture"></i> Dashboard</a></li>
	            <li><a href="messages.html"><i class="pe-7s-mail"></i> Messages <span class="tag">6</span></a></li>
	            <li><a href="bookings.html"><i class="pe-7s-date"></i>Bookings</a></li>
	            <li><a href="my-properties.html"><i class="pe-7s-diamond"></i>My Properties</a></li>
	            <li class="active"><a href="my-invoices.html"><i class="pe-7s-note2"></i>My Invoices</a></li>
	            <li><a href="favorited-properties.html"><i class="pe-7s-like2"></i>Favorited Properties</a></li>
	            <li><a href="submit-property.html"><i class="pe-7s-up-arrow"></i>Submit Property</a></li>
	            <li><a href="my-profile.html"><i class="pe-7s-user"></i>My Profile</a></li>
	            <li><a href="../index-2.html"><i class="pe-7s-back-2"></i>Logout</a></li>
	        </ul>
	    </div>
    </section>
    <!--End Hidden Bar -->

    <div class="dashboard">
	    <div class="container-fluid">
	        <div class="content-area">
	            <div class="dashboard-content">
	                <div class="dashboard-header clearfix">
	                    <div class="row">
	                        <div class="col-md-6 col-sm-12"><h4>My Invoices</h4></div>
	                        <div class="col-md-6 col-sm-12">
	                            <div class="breadcrumb-nav">
	                                <ul>
	                                    <li><a href="../index-2.html">Index</a></li>
	                                    <li><a href="dashboard.html">Dashboard</a></li>
	                                    <li class="active">Invoices</li>
	                                </ul>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="row">
	                    <div class="column col-lg-12">
	                    	<div class="my-invoices">
	                    		<div class="title"><h3>Invoice</h3></div>
	                    		<div class="inner-container clearfix">
	                				<div class="logo"><a href="#"><img src="images/logo-small.png" alt=""></a></div>
	                				<div class="order-num">Order # 12345</div>
	                    			<div class="invoice-box">
	                    				<div class="row">
	                    					<div  class="column col-lg-3 col-md-6 col-sm-12">
                    							<h3>Shipped To:</h3>
                    							<ul class="invoice-info">
                    								<li>Daniel Deve</li>
                    								<li>Harvest St, North Subract 360</li>
                    								<li>London. United States Of Amrica.</li>
                    								<li>Springfield, ST 35436</li>
                    								<li><a href="#">info@willies.com</a></li>
                    							</ul>
                    						</div>
	                    					<div  class="column col-lg-3 col-md-6 col-sm-12">
                    							<h3>Billed To:</h3>
                    							<ul class="invoice-info">
                    								<li>Daniel Deve</li>
                    								<li>Harvest St, North Subract 360</li>
                    								<li>London. United States Of Amrica.</li>
                    								<li>Springfield, ST 35436</li>
                    								<li><a href="#">info@willies.com</a></li>
                    							</ul>
                    						</div>
	                    					<div  class="column col-lg-3 col-md-6 col-sm-12">
                    							<h3>Payment Method</h3>
                    							<ul class="invoice-info">
                    								<li>Visa ending 5453</li>
                    								<li><a href="#">info@willies.com</a></li>
                    							</ul>
                    						</div>
                    						<div  class="column col-lg-3 col-md-6 col-sm-12">
                    							<h3>Order Date:</h3>
                    							<ul class="invoice-info">
                    								<li>August 3,2018</li>
                    							</ul>
                    						</div>
	                    				</div>

            							<div class="table-responsive ">
                                            <table class="table">
                                                <thead>
                                                <tr>
                                                    <td><strong>#</strong></td>
                                                    <td><strong>Item</strong></td>
                                                    <td class="text-center"><strong>Price</strong></td>
                                                    <td class="text-center"><strong>Quantity</strong></td>
                                                    <td class="text-right"><strong>Totals</strong></td>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td><strong>1</strong></td>
                                                    <td>BS-350</td>
                                                    <td class="text-center">$30.99</td>
                                                    <td class="text-center">2</td>
                                                    <td class="text-right">$30.99</td>
                                                </tr>
                                                <tr>
                                                    <td><strong>2</strong></td>
                                                    <td>BS-700</td>
                                                    <td class="text-center">$60.00</td>
                                                    <td class="text-center">3</td>
                                                    <td class="text-right">$60.00</td>
                                                </tr>
                                                <tr>
                                                    <td><strong>3</strong></td>
                                                    <td>BS-950</td>
                                                    <td class="text-center">$90.00</td>
                                                    <td class="text-center">1</td>
                                                    <td class="text-right">$90.00</td>
                                                </tr>
                                                <tr>
                                                    <td><strong>4</strong></td>
                                                    <td>BS-1200</td>
                                                    <td class="text-center">$120.00</td>
                                                    <td class="text-center">4</td>
                                                    <td class="text-right">$120.00</td>
                                                </tr>
                                                <tr>
                                                    <td><strong>5</strong></td>
                                                    <td>BS-1450</td>
                                                    <td class="text-center">$150.00</td>
                                                    <td class="text-center">5</td>
                                                    <td class="text-right">$150.00</td>
                                                </tr>
                                                <tr>
                                                    <td class="no-line"></td>
                                                    <td class="no-line"></td>
                                                    <td class="no-line"></td>
                                                    <td class="no-line text-center"><strong>Total</strong></td>
                                                    <td class="no-line text-right">$550.99</td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
	                    			</div>
	                    		</div>
	                    	</div>
	                    </div>
	                </div>
	            </div>
	            <p class="copyright-text">© 2018 <a href="#">Expert Themes</a> All right reserved.</p>
	        </div>
	    </div>
	</div>

</div>
    
<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/dropzone.js"></script>
<script src="js/appear.js"></script>
<script src="js/script.js"></script>
</body>

<!-- Mirrored from expert-themes.com/html/willies/admin/my-invoices.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 11 Dec 2018 11:41:22 GMT -->
</html>