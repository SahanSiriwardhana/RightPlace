<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from expert-themes.com/html/willies/admin/favorited-properties.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 11 Dec 2018 11:41:23 GMT -->
<head>
<meta charset="utf-8">
<title>Willies - Real Estate HTML Template | Favorited Properties</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">

    <!-- Preloader -->
    <div class="preloader"></div>

    <!-- Header Span -->
    <span class="header-span"></span>

    <!-- Main Header-->
    <header class="main-header">
        <div class="main-box clearfix">
        	<!-- Logo Box -->
            <div class="logo-box">
                <div class="logo"><a href="../index-2.html"><img src="images/logo-small.png" alt="" title=""></a></div>
            </div>

            <!-- Upper Right-->
            <div class="upper-right">
                <ul class="clearfix">
                    <li class="dropdown option-box">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="images/resource/thumb-1.jpg" alt="avatar" class="thumb">My Account</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="dashboard.html">Dashboard</a>
                            <a class="dropdown-item" href="messages.html">Messages</a>
                            <a class="dropdown-item" href="bookings.html">Bookings</a>
                            <a class="dropdown-item" href="my-profile.html">My profile</a>
                            <a class="dropdown-item" href="../index-2.html">Log out</a>
                        </div>
                    </li>
                    <li class="submit-property">
                    	<a href="submit-property.html" class="theme-btn btn-style-one">Submit Property <i class="pe-7s-up-arrow"></i></a>
                    </li>
                    <li class="nav-toggler">
                    	<button class="toggler-btn nav-btn"><span class="bar bar-one"></span><span class="bar bar-two"></span><span class="bar bar-three"></span></button>
                    </li>
                </ul>
            </div>
        </div>
        <!--End Header Lower-->
    </header>
    <!--End Main Header -->
    
    <!-- Hidden Bar -->
    <section class="hidden-bar">
        <div class="dashboard-inner">
        	<div class="cross-icon"><span class="pe-7s-close-circle"></span></div>
        	<ul class="navigation">
	            <li><a href="dashboard.html"><i class="pe-7s-culture"></i> Dashboard</a></li>
	            <li><a href="messages.html"><i class="pe-7s-mail"></i> Messages <span class="tag">6</span></a></li>
	            <li><a href="bookings.html"><i class="pe-7s-date"></i>Bookings</a></li>
	            <li><a href="my-properties.html"><i class="pe-7s-diamond"></i>My Properties</a></li>
	            <li><a href="my-invoices.html"><i class="pe-7s-note2"></i>My Invoices</a></li>
	            <li class="active"><a href="favorited-properties.html"><i class="pe-7s-like2"></i>Favorited Properties</a></li>
	            <li><a href="submit-property.html"><i class="pe-7s-up-arrow"></i>Submit Property</a></li>
	            <li><a href="my-profile.html"><i class="pe-7s-user"></i>My Profile</a></li>
	            <li><a href="../index-2.html"><i class="pe-7s-back-2"></i>Logout</a></li>
	        </ul>
	    </div>
    </section>
    <!--End Hidden Bar -->

    <div class="dashboard">
	    <div class="container-fluid">
	        <div class="content-area">
	            <div class="dashboard-content">
	                <div class="dashboard-header clearfix">
	                    <div class="row">
	                        <div class="col-md-6 col-sm-12"><h4>Favorited Properties</h4></div>
	                        <div class="col-md-6 col-sm-12">
	                            <div class="breadcrumb-nav">
	                                <ul>
	                                    <li><a href="../index-2.html">Index</a></li>
	                                    <li><a href="dashboard.html">Dashboard</a></li>
	                                    <li class="active">Properties</li>
	                                </ul>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="row">
	                    <div class="column col-lg-12">
	                    	<div class="properties-box">
	                    		<div class="title"><h3>My Favorited Properties</h3></div>
	                    		<div class="inner-container">
	                                <!-- Property Block -->
			                        <div class="property-block">
			                        	<div class="inner-box clearfix">
	                                        <div class="image-box">
	                                            <figure class="image"><img src="images/resource/property-1.jpg" alt=""></figure>
	                                        </div>
	                                        <div class="content-box">
	                                            <h3>Single House Near Orland Park.</h3>
	                                            <div class="location"><i class="la la-map-marker"></i> Orland Park, IL 35785, Chicago, United State</div>
	                                            <ul class="property-info clearfix">
	                                                <li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
	                                                <li><i class="flaticon-bed"></i> 4 Bedrooms</li>
	                                                <li><i class="flaticon-car"></i> 2 Garage</li>
	                                                <li><i class="flaticon-bathtub"></i> 3 Bathroom</li>
	                                            </ul>
	                                            <div class="price">$ 13,65,000</div>
	                                        </div>
		                                    <div class="option-box">
		                                        <div class="expire-date">4.01.2018</div>
		                                        <ul class="action-list">
		                                        	<li><a href="#"><i class="la la-edit"></i> Edit</a></li>
		                                        	<li><a href="#"><i class="la la-eye-slash"></i> Hide</a></li>
		                                        	<li><a href="#"><i class="la la-trash-o"></i> Delete</a></li>
		                                        </ul>
		                                    </div>
			                        	</div>
                                    </div>

                                    <!-- Property Block -->
			                        <div class="property-block">
			                        	<div class="inner-box clearfix">
	                                        <div class="image-box">
	                                            <figure class="image"><img src="images/resource/property-2.jpg" alt=""></figure>
	                                        </div>
	                                        <div class="content-box">
	                                            <h3>Apartment Morden 1243, W No.</h3>
	                                            <div class="location"><i class="la la-map-marker"></i> Orland Park, IL 35785, Chicago, United State</div>
	                                            <ul class="property-info clearfix">
	                                                <li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
	                                                <li><i class="flaticon-bed"></i> 4 Bedrooms</li>
	                                                <li><i class="flaticon-car"></i> 2 Garage</li>
	                                                <li><i class="flaticon-bathtub"></i> 3 Bathroom</li>
	                                            </ul>
	                                            <div class="price">$ 13,65,000</div>
	                                        </div>
		                                    <div class="option-box">
		                                        <div class="expire-date">4.01.2018</div>
		                                        <ul class="action-list">
		                                        	<li><a href="#"><i class="la la-edit"></i> Edit</a></li>
		                                        	<li><a href="#"><i class="la la-eye-slash"></i> Hide</a></li>
		                                        	<li><a href="#"><i class="la la-trash-o"></i> Delete</a></li>
		                                        </ul>
		                                    </div>
			                        	</div>
                                    </div>

                                    <!-- Property Block -->
			                        <div class="property-block">
			                        	<div class="inner-box clearfix">
	                                        <div class="image-box">
	                                            <figure class="image"><img src="images/resource/property-3.jpg" alt=""></figure>
	                                        </div>
	                                        <div class="content-box">
	                                            <h3>Great Home for Single fmaily.</h3>
	                                            <div class="location"><i class="la la-map-marker"></i> Orland Park, IL 35785, Chicago, United State</div>
	                                            <ul class="property-info clearfix">
	                                                <li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
	                                                <li><i class="flaticon-bed"></i> 4 Bedrooms</li>
	                                                <li><i class="flaticon-car"></i> 2 Garage</li>
	                                                <li><i class="flaticon-bathtub"></i> 3 Bathroom</li>
	                                            </ul>
	                                            <div class="price">$ 13,65,000</div>
	                                        </div>
		                                    <div class="option-box">
		                                        <div class="expire-date">4.01.2018</div>
		                                        <ul class="action-list">
		                                        	<li><a href="#"><i class="la la-edit"></i> Edit</a></li>
		                                        	<li><a href="#"><i class="la la-eye-slash"></i> Hide</a></li>
		                                        	<li><a href="#"><i class="la la-trash-o"></i> Delete</a></li>
		                                        </ul>
		                                    </div>
			                        	</div>
                                    </div>

                                    <!-- Property Block -->
			                        <div class="property-block">
			                        	<div class="inner-box clearfix">
	                                        <div class="image-box">
	                                            <figure class="image"><img src="images/resource/property-4.jpg" alt=""></figure>
	                                        </div>
	                                        <div class="content-box">
	                                            <h3>Single House Near Orland Park.</h3>
	                                            <div class="location"><i class="la la-map-marker"></i> Orland Park, IL 35785, Chicago, United State</div>
	                                            <ul class="property-info clearfix">
	                                                <li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
	                                                <li><i class="flaticon-bed"></i> 4 Bedrooms</li>
	                                                <li><i class="flaticon-car"></i> 2 Garage</li>
	                                                <li><i class="flaticon-bathtub"></i> 3 Bathroom</li>
	                                            </ul>
	                                            <div class="price">$ 13,65,000</div>
	                                        </div>
		                                    <div class="option-box">
		                                        <div class="expire-date">4.01.2018</div>
		                                        <ul class="action-list">
		                                        	<li><a href="#"><i class="la la-edit"></i> Edit</a></li>
		                                        	<li><a href="#"><i class="la la-eye-slash"></i> Hide</a></li>
		                                        	<li><a href="#"><i class="la la-trash-o"></i> Delete</a></li>
		                                        </ul>
		                                    </div>
			                        	</div>
                                    </div>

                                    <!-- Property Block -->
			                        <div class="property-block">
			                        	<div class="inner-box clearfix">
	                                        <div class="image-box">
	                                            <figure class="image"><img src="images/resource/property-5.jpg" alt=""></figure>
	                                        </div>
	                                        <div class="content-box">
	                                            <h3>Apartment Morden 1243, W No.</h3>
	                                            <div class="location"><i class="la la-map-marker"></i> Orland Park, IL 35785, Chicago, United State</div>
	                                            <ul class="property-info clearfix">
	                                                <li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
	                                                <li><i class="flaticon-bed"></i> 4 Bedrooms</li>
	                                                <li><i class="flaticon-car"></i> 2 Garage</li>
	                                                <li><i class="flaticon-bathtub"></i> 3 Bathroom</li>
	                                            </ul>
	                                            <div class="price">$ 13,65,000</div>
	                                        </div>
		                                    <div class="option-box">
		                                        <div class="expire-date">4.01.2018</div>
		                                        <ul class="action-list">
		                                        	<li><a href="#"><i class="la la-edit"></i> Edit</a></li>
		                                        	<li><a href="#"><i class="la la-eye-slash"></i> Hide</a></li>
		                                        	<li><a href="#"><i class="la la-trash-o"></i> Delete</a></li>
		                                        </ul>
		                                    </div>
			                        	</div>
                                    </div>

                                    <!-- Property Block -->
			                        <div class="property-block">
			                        	<div class="inner-box clearfix">
	                                        <div class="image-box">
	                                            <figure class="image"><img src="images/resource/property-6.jpg" alt=""></figure>
	                                        </div>
	                                        <div class="content-box">
	                                            <h3>Great Home for Single fmaily.</h3>
	                                            <div class="location"><i class="la la-map-marker"></i> Orland Park, IL 35785, Chicago, United State</div>
	                                            <ul class="property-info clearfix">
	                                                <li><i class="flaticon-dimension"></i> 356 Sq-Ft</li>
	                                                <li><i class="flaticon-bed"></i> 4 Bedrooms</li>
	                                                <li><i class="flaticon-car"></i> 2 Garage</li>
	                                                <li><i class="flaticon-bathtub"></i> 3 Bathroom</li>
	                                            </ul>
	                                            <div class="price">$ 13,65,000</div>
	                                        </div>
		                                    <div class="option-box">
		                                        <div class="expire-date">4.01.2018</div>
		                                        <ul class="action-list">
		                                        	<li><a href="#"><i class="la la-edit"></i> Edit</a></li>
		                                        	<li><a href="#"><i class="la la-eye-slash"></i> Hide</a></li>
		                                        	<li><a href="#"><i class="la la-trash-o"></i> Delete</a></li>
		                                        </ul>
		                                    </div>
			                        	</div>
                                    </div>
	                    		</div>
	                    	</div>
	                    </div>
	                </div>
	            </div>
	            <p class="copyright-text">© 2018 <a href="#">Expert Themes</a> All right reserved.</p>
	        </div>
	    </div>
	</div>

</div>
    
<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/dropzone.js"></script>
<script src="js/appear.js"></script>
<script src="js/script.js"></script>
</body>

<!-- Mirrored from expert-themes.com/html/willies/admin/favorited-properties.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 11 Dec 2018 11:41:23 GMT -->
</html>